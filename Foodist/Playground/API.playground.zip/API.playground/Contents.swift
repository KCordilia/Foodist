import Foundation

struct Recipe: Codable {
    let id: Int
    let title: String
    let readyInMinutes: Int
    let servings: Int
    let image: String
    let instructions: String
}

func getAPIData(completion: @escaping (Data) -> Void) {
    let session = URLSession.shared
    guard
        let url = URL(string:"https://spoonacular-recipe-food-nutrition-v1.p.rapidapi.com/recipes/262682/information")
        else { return }
    var request = URLRequest(url: url)
    request.addValue("spoonacular-recipe-food-nutrition-v1.p.rapidapi.com", forHTTPHeaderField: "X-RapidAPI-Host")
    request.addValue("6d4b0c4e3bmsh16b8d0615ae873bp1510ccjsnc4cc6ac1e186", forHTTPHeaderField: "X-RapidAPI-Key")
    
    
    let task = session.dataTask(with: url) { (data, response, error) in
        print(data!)
        print(response!)
        print(error!)
    }
    task.resume()
}

getAPIData { resultData in
    do {
        let decoder = JSONDecoder()
        let decodedResult = try decoder.decode(Recipe.self, from: resultData)
        print(decodedResult)
    } catch {
        print("failed")
    }
}
